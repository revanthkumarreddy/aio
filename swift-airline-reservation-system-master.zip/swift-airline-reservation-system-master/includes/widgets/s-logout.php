							<ul class="nav pull-right" role="navigation">
		    					<li class="dropdown">
		    						<a href="#" id="link1" role="button" class="dropdown-toggle" data-toggle="dropdown">
		    							Hi, <?php echo $student_data['student_fname']; ?>
		    							<b class="caret"></b>
		    						</a>
		    						<ul class="dropdown-menu" role="menu">
		    							<li><a href="http://tofsis.com/student/<?php echo $student_data['student_uname']; ?>">Profile</a></li>
	
		    							<li><a href="http://tofsis.com/student/settings.php">Settings</a></li>
		    							<li><a href="http://tofsis.com/student/changepass.php">Change Password</a></li>
		    							<li><a href="http://tofsis.com/student/logout.php">Log Out</a></li>
		    						</ul>
		    					</li>
							</ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
