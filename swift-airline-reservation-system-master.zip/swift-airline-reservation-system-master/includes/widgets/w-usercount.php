<?php

	echo user_count();

?>